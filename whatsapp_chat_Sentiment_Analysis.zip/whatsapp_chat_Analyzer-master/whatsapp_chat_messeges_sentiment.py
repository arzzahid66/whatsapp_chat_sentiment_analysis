import streamlit as st
import preprocesser, helper
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import nltk

nltk.download('vader_lexicon')
from nltk.sentiment import SentimentIntensityAnalyzer
st.sidebar.title("Whatsapp Chat Analyzer")
uploaded_file = st.sidebar.file_uploader("Choose a file")
if uploaded_file is not None:
    bytes_data = uploaded_file.getvalue()
    data = bytes_data.decode("utf-8")
    df = preprocesser.preprocess(data)
    df.head()
    # fetch unique users
    user_list = df['user'].unique().tolist()
    user_list.sort()
    user_list.insert(0,"overall")
    selected_user = st.sidebar.selectbox("Show analysis wrt",user_list)

    if st.sidebar.button("Show Analysis"):
        # Stats Area
        num_messages, words, num_media_messages, num_links = helper.fetch_stats(selected_user,df)
        st.title("Top Statistics of Whatsapp chat by A_R_Z")
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.header("Total Messages")
            st.title(num_messages)
        with col2:
            st.header("Total Words")
            st.title(words)
        with col3:
            st.header("Media Shared")
            st.title(num_media_messages)
        with col4:
            st.header("Links Shared")
            st.title(num_links)
        # Monthly_timeline 
        st.title("Monthly Timeline")
        timeline=helper.monthly_timeline(selected_user,df)
        fig,ax=plt.subplots()
        ax.plot(timeline['time'],timeline['message'],color='green')
        plt.xticks(rotation='vertical')
        st.pyplot(fig)

        # daily timeline 
        st.title("Daily Timeline")
        daily_timeline=helper.daily_timeline(selected_user,df)
        fig,ax=plt.subplots()
        ax.plot(daily_timeline['only_date'],daily_timeline['message'],color='blue')
        plt.xticks(rotation='vertical')
        st.pyplot(fig)
        
        # week activity map
        st.title('Activity Map')

        col1,col2 = st.columns(2)
        with col1:
            st.header('Most Busy Day')
            busy_day=helper.week_activity_map(selected_user,df)
            fig,ax=plt.subplots()
            ax.bar(busy_day.index,busy_day.values)
            plt.xticks(rotation='vertical')

            st.pyplot(fig)
        with col2:
            st.header('Most Busy Month')
            busy_moth=helper.month_activity_map(selected_user,df)
            fig,ax=plt.subplots()
            ax.bar(busy_moth.index,busy_moth.values,color='green')
            plt.xticks(rotation='vertical')

            st.pyplot(fig)
        # activity heat map
            
        st.title("Weekly Activity Map")
        user_heatmap=helper.activity_heatmap(selected_user,df)
        fig,ax=plt.subplots()
        ax= sns.heatmap(user_heatmap)
        st.pyplot(fig)


        # finding the most busy user in group 
        st.title('Most Busy User')
        x, new_df = helper.most_busy_users(df)
        fig, ax = plt.subplots()
        ax.barh(x.index, x.values,color='red')
        plt.xticks(rotation='vertical')
        st.dataframe(new_df)
        st.pyplot(fig)

        # wordcloud 
        st.title('WordCloud')
        df_wc = helper.create_wordcloud(selected_user,df) 
        fig,ax = plt.subplots()
        ax.imshow(df_wc) 
        st.pyplot(fig)         

        # most common words 
        most_common_df=helper.most_common_words(selected_user,df)
        fig,ax=plt.subplots()
        ax.barh(most_common_df[0],most_common_df[1])
        plt.xticks(rotation='vertical')
        st.title('Most Common Words')
        st.pyplot(fig)

        # emoji analysis
        emoji_df=helper.emoji_helper(selected_user,df)
        st.title('Emoji Analysis')
        col1,col2 =st.columns(2)
        with col1:
            st.dataframe(emoji_df)
        with col2:
            fig = plt.figure(figsize=(10, 6))
            ax = fig.add_subplot()
            ax.pie(emoji_df['count'].head(), labels=emoji_df['emoji'].head(), autopct='%1.1f%%')
            st.pyplot(fig)
        cleaned_df = df.copy()
        if 'message_tokens' in cleaned_df.columns:
            cleaned_df = cleaned_df.drop(columns=['message_tokens'])
        csv_data = cleaned_df.to_csv(index=False)
        csv_file = f"cleaned_whatsapp_data.csv"
        st.download_button(
        label="Download Cleaned Data csv formate",
        data=csv_data,
        file_name=csv_file,
        mime="text/csv",
        ) 

        # ... (your existing code)

# ... (your existing code)

# Sentiment Analysis
# st.title("Sentiment Analysis")

# if st.sidebar.button("Show Sentiment Analysis"):
#     if selected_user != "overall":
#         user_messages = df[df["user"] == selected_user]["message"]
#         sid = SentimentIntensityAnalyzer()
#         sentiment_scores = user_messages.apply(lambda x: sid.polarity_scores(x))
#         sentiment_df = pd.DataFrame(list(sentiment_scores))
#         sentiment_df["compound_label"] = sentiment_df["compound"].apply(lambda x: "Positive" if x >= 0 else "Negative")
#         st.header("Sentiment Analysis for {}".format(selected_user))
#         st.dataframe(sentiment_df)

#         # Plot sentiment distribution
#         st.title("Sentiment Distribution")
#         fig, ax = plt.subplots()
#         ax.hist(sentiment_df["compound"], bins=20, color='orange', edgecolor='black')
#         ax.set_xlabel("Compound Sentiment Score")
#         ax.set_ylabel("Frequency")
#         st.pyplot(fig)  # Use st.pyplot() instead of plt.show()


# Sentiment Analysis
st.title("Sentiment Analysis")

if st.sidebar.button("Show Sentiment Analysis"):
    if selected_user != "overall":
        user_messages = df[df["user"] == selected_user]["message"]
        sid = SentimentIntensityAnalyzer()
        sentiment_scores = user_messages.apply(lambda x: sid.polarity_scores(x))
        sentiment_df = pd.DataFrame(list(sentiment_scores))
        sentiment_df["compound_label"] = sentiment_df["compound"].apply(lambda x: "Positive" if x >= 0 else "Negative")
        st.header("Sentiment Analysis for {}".format(selected_user))
        st.dataframe(sentiment_df)

        # Plot sentiment distribution
        st.title("Sentiment Distribution")
        fig, ax = plt.subplots()
        ax.hist(sentiment_df["compound"], bins=20, color='orange', edgecolor='black')
        ax.set_xlabel("Compound Sentiment Score")
        ax.set_ylabel("Frequency")
        st.pyplot(fig)  # Use st.pyplot() instead of plt.show()

# Sentiment Analysis for User Input
st.title("Sentiment Analysis for User Input")

# Text input for the user to enter a message
user_input_message = st.text_area("Enter a text message:")

# Button to trigger sentiment analysis for user input
if st.button("Show Sentiment for User Input", key="user_input_sentiment_button"):
    if user_input_message:
        sid = SentimentIntensityAnalyzer()
        input_sentiment_score = sid.polarity_scores(user_input_message)["compound"]
        input_sentiment_label = "Positive" if input_sentiment_score >= 0 else "Negative"

        st.subheader("Sentiment Analysis for the User Input Message:")
        st.write(f"Message: {user_input_message}")
        st.write(f"Compound Sentiment Score: {input_sentiment_score}")
        st.write(f"Sentiment Label: {input_sentiment_label}")